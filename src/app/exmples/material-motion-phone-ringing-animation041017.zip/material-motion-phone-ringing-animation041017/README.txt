A Pen created at CodePen.io. You can find this one at https://codepen.io/callmenick/pen/XdwmeV.

 Reference - https://material-design.storage.googleapis.com/publish/material_v_8/material_ext_publish/0B14F_FSUCc01Y09iZVJNcktPalE/Intentional_02_Ring-v3.webm