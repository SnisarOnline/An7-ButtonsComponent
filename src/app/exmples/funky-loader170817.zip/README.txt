A Pen created at CodePen.io. You can find this one at https://codepen.io/Jackthomsonn/pen/wModMm.

 Hey guys! I just wanted to create a simple funky loading animation! Always wanted to make something like this :p! I hope you like it :D!